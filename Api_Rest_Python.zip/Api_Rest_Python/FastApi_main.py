# Este es el servicio Rest como tal, quien recibe las peticiones desde el exterior

# Si quieres utilizar este main con FastAPI, solo es lo renombres como main y el que hay le coloques otro nombre

"""
        FastAPI es un framework para crear APIS, tales como REST APIS o APIS RPC.
        FastAPI promete ayudarnos a crear APIS rápidas de manera sencilla,
        con muy poco código y con un rendimiento extraordinario, para soportar
        sitios web de alta concurrencia, es extremadamente rápido y lo mejor es
        que utiliza muy poco código comparado con otros frameworks.
"""

from fastapi import FastAPI, Request, Body

from BLL.Controlador import Controlador
from BO.Usuario import Usuario
from BLL.Funciones import Funciones

app = FastAPI()


# Definición de rutas 
@app.get("/usuarios")
def get_usuarios():
    resultados = []
    cont = Funciones.crearControlador();
    resultado = cont.obtenerListadoUsuarios()
    claves = ['usuario_id', 'nombres', 'apellidos']
    for usuarios in resultado:
        listaUsuarios = dict(zip(claves, usuarios)) 
        resultados.append(listaUsuarios)
    return {"Listado Usuarios":resultados}


@app.get("/usuario/{id}")
def get_usuario_by_id(id):    
    if (id.isnumeric() == False):    
        return response(Funciones.OK, 'Error', Funciones.NUMERICO)
    else:
         usuario = Usuario()
         cont = Funciones.crearControlador();
         usuario = cont.obtenerUsuario(id)
         if (usuario != [None]):
             return {"Usuario_id":  usuario.usuario_id, "Nombres": usuario.nombres ,"Apellidos": usuario.apellidos}
         else:
              return response(Funciones.OK, 'Error', Funciones.ERRORUD)
    
@app.post("/usuario")
async def insert_usuario(body = Body()):
    id = str(body['usuario_id'])
    if ((len(body['nombres']) ==0) or (len(body['apellidos']) ==0)):        
        return response(Funciones.UNPROCESSABLE_ENTITY, 'Error', Funciones.ERRORSD)
    elif (id.isnumeric() == False):    
         return response(Funciones.OK, 'Error', Funciones.NUMERICO)
    else:       
        usuario = Usuario()
        usuario.usuario_id = 0
        usuario.nombres  = body['nombres']
        usuario.apellidos = body['apellidos']
        cont = Funciones.crearControlador();
        result = cont.guardarUsuario(usuario)
        if (result == 0):            
            return response(Funciones.OK, 'Exito', Funciones.EXITOI)
        else:            
            return response(Funciones.OK, 'Error', Funciones.ERRORDB)

    
@app.put("/usuario")
def update_usuario(body = Body()):
    id = str(body['usuario_id'])    
    if ((len(body['nombres']) ==0) or (len(body['apellidos']) ==0)):        
        return response(Funciones.UNPROCESSABLE_ENTITY, 'Error', Funciones.ERRORSD)
    elif (id.isnumeric() == False):    
         return response(Funciones.OK, 'Error', Funciones.NUMERICO)
    else:
        usuario = Usuario()
        usuario.usuario_id = int(body['usuario_id'])
        usuario.nombres  = body['nombres']
        usuario.apellidos = body['apellidos']
        cont = Funciones.crearControlador();        
        result = cont.guardarUsuario(usuario)
        if (result == 0):
            return response(Funciones.OK, 'Exito', Funciones.EXITOU)
        elif (result == -2):
              return response(Funciones.OK, 'Error', Funciones.ERRORUD)
        else:
            return response(Funciones.OK, 'Error', Funciones.ERRORDB)
        
@app.delete("/usuario/{id}")
def delete_usuario(id: int):    
    cont = Funciones.crearControlador();
    result = cont.eliminarUsuario(id)
    if (result == 0):            
        return response(Funciones.OK, 'Exito', Funciones.EXITOD)
    elif (result == -2):              
          return response(Funciones.OK, 'Error', Funciones.ERRORUD)
    else:        
         return response(Funciones.OK, 'Error', Funciones.ERRORDB)
       

def response(code, status, message):    
    return ({"Codigo":  code, "Estado": status ,"Mensaje": message})

 


