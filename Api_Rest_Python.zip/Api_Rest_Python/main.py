from flask import Flask, jsonify, request
from BLL.Controlador import Controlador
from BO.Usuario import Usuario
from BLL.Funciones import Funciones

app = Flask(__name__)

# Definición de rutas 

@app.route('/usuarios', methods=["GET"])
def get_usuarios():
    resultados = []
    cont = Funciones.crearControlador();
    resultado = cont.obtenerListadoUsuarios()
    claves = ['usuario_id', 'nombres', 'apellidos']
    for usuarios in resultado:
        listaUsuarios = dict(zip(claves, usuarios)) 
        resultados.append(listaUsuarios)
    return jsonify({"Listado Usuarios":resultados})


@app.route("/usuario/<id>", methods=["GET"])
def get_usuario_by_id(id):    
    if (id.isnumeric() == False):    
        return response(Funciones.OK, 'Exito', Funciones.NUMERICO)
    else:
         usuario = Usuario()
         cont = Funciones.crearControlador();
         usuario = cont.obtenerUsuario(id)
         return jsonify({"Usuario_id":  usuario.usuario_id, "Nombres": usuario.nombres ,"Apellidos": usuario.apellidos})
         #return json.dumps(usuario.__dict__) 
        
    
@app.route("/usuario", methods=["POST"])
def insert_usuario():
    data = request.get_json()
    id = str(data["usuario_id"])
    if ((len(data["nombres"]) ==0) or (len(data["apellidos"]) ==0)):        
        return response(Funciones.UNPROCESSABLE_ENTITY, 'Error', Funciones.ERRORSD)
    elif (id.isnumeric() == False):    
         return response(Funciones.OK, 'Error', Funciones.NUMERICO)
    else:    
        usuario = Usuario()
        usuario.usuario_id = 0
        usuario.nombres  = data["nombres"]
        usuario.apellidos = data["apellidos"]
        cont = Funciones.crearControlador();
        result = cont.guardarUsuario(usuario)        
        if (result == 0):            
            return response(Funciones.OK, 'Exito', Funciones.EXITOI)
        else:            
            return response(Funciones.OK, 'Error', Funciones.ERRORDB)

    
@app.route("/usuario", methods=["PUT"])
def update_usuario():
    data = request.get_json()    
    id = str(data["usuario_id"])    
    if ((len(data["nombres"]) ==0) or (len(data["apellidos"]) ==0)):
        return response(Funciones.UNPROCESSABLE_ENTITY, 'Error', Funciones.ERRORSD)
    elif (id.isnumeric() == False):    
         return response(Funciones.OK, 'Error', Funciones.NUMERICO)
    else:
        usuario = Usuario()
        usuario.usuario_id = int(data["usuario_id"])
        usuario.nombres  = data["nombres"]
        usuario.apellidos = data["apellidos"]
        cont = Funciones.crearControlador();        
        result = cont.guardarUsuario(usuario)
        if (result == 0):
            return response(Funciones.OK, 'Exito', Funciones.EXITOU)
        elif (result == -2):
              return response(Funciones.OK, 'Error', Funciones.ERRORUD)
        else:
            return response(Funciones.OK, 'Error', Funciones.ERRORDB)
        
@app.route("/usuario/<id>", methods=["DELETE"])
def delete_usuario(id):
    if (id.isnumeric() == False):      
        return response(Funciones.OK, 'Error', Funciones.NUMERICO)
    else:
        cont = Funciones.crearControlador();
        result = cont.eliminarUsuario(id)
        if (result == 0):            
            return response(Funciones.OK, 'Exito', Funciones.EXITOD)
        elif (result == -2):              
              return response(Funciones.OK, 'Error', Funciones.ERRORUD)
        else:        
            return response(Funciones.OK, 'Error', Funciones.ERRORDB)
       

def response(code, status, message):    
    return jsonify({"Codigo":  code, "Estado": status ,"Mensaje": message})

@app.after_request
def after_request(response):
    response.headers["Access-Control-Allow-Origin"] = "*" 
    response.headers["Access-Control-Allow-Credentials"] = "true"
    response.headers["Access-Control-Allow-Methods"] = "POST, GET, OPTIONS, PUT, DELETE"
    response.headers["Access-Control-Allow-Headers"] = "Accept, Content-Type, Content-Length, Accept-Encoding, X-CSRF-Token, Authorization"
    return response


if __name__ == "__main__":    
    app.run(host='0.0.0.0', port=8000, debug=False)