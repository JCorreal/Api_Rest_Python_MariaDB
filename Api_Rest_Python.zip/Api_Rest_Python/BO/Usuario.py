
class Usuario:
    
    def __init__(self):
            self._usuario_id = int(0)
            self._nombres = str('')
            self._apellidos = str('')
    
    @property    
    def usuario_id(self):
        return self._usuario_id
    
    @property
    def nombres(self):
        return self._nombres
    
    @property
    def apellidos(self):
        return self._apellidos
        
    @usuario_id.setter
    def usuario_id(self, usuario_id):
        self._usuario_id = usuario_id
        
    @nombres.setter    
    def nombres(self, nombres):
        self._nombres = nombres

    @apellidos.setter
    def apellidos(self, apellidos):
        self._apellidos = apellidos
            
