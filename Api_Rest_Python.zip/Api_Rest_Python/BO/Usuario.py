class Usuario:
    
    usuario_id = 0
    nombres =''
    apellidos = ''