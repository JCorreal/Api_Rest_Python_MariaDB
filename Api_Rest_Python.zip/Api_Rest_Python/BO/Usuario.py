class Usuario:
    
    usuario_id = ''
    nombres =''
    apellidos = ''