# Aquí emplearemos el patrón de Creación: Factory Method

from DAL.AccesoDatos import AccesoDatos
from DAL.IAccesoDatos import IAccesoDatos

class AccesoDatosFactory:
    
    @staticmethod        
    def obtenerAccesoDatos(iaccesodatos = IAccesoDatos):
        return AccesoDatos()
         
        
        
