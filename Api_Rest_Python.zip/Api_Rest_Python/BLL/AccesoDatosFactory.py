from DAL.AccesoDatos import AccesoDatos
from DAL.IAccesoDatos import IAccesoDatos

class AccesoDatosFactory:
    
    @staticmethod        
    def obtenerAccesoDatos(iaccesodatos = IAccesoDatos):
        return AccesoDatos()
         
        
        
