from DAL.IAccesoDatos import IAccesoDatos
from DAL.AccesoDatos import AccesoDatos
from BO.Usuario import Usuario

class Controlador:
        
     def __init__(self, accesoDatos = IAccesoDatos):    
         self._accesoDatos = accesoDatos
   
     def obtenerListadoUsuarios(self):
         usuarios = []
         usuarios = self._accesoDatos.obtenerListadoUsuarios()
         return usuarios
        
     def obtenerUsuario(self, id):         
         usuario = Usuario()
         usuario = self._accesoDatos.obtenerUsuario(id)
         return usuario
        
     def guardarUsuario(self, usuario):         
         resultado = self._accesoDatos.guardarUsuario(usuario)    
         return resultado
    
     def eliminarUsuario(self, id):         
         resultado = self._accesoDatos.eliminarUsuario(id)    
         return resultado