from BLL.AccesoDatosFactory import AccesoDatosFactory
from DAL.AccesoDatos import AccesoDatos
from BLL.Controlador import Controlador

class Funciones:
    
    @staticmethod
    def crearControlador():
        accesodatos = AccesoDatos()
        accesodatos = AccesoDatosFactory.obtenerAccesoDatos()
        return Controlador (accesodatos)
        
    # Constantes de errores
    OK = 200
    MOVED_PERMANENTLY = 301
    FOUND = 302
    UNAUTHORIZED = 401
    FORBIDDEN = 403
    NOT_FOUND = 404
    METHOD_NOT_ALLOWED = 405
    CONFLICT = 409
    UNPROCESSABLE_ENTITY = 422
    FAILED_DEPENDENCY = 424
    INTERNAL_SERVER_ERROR = 500
           
    EXITOI = "El nuevo registro ha sido grabado"
    EXITOU = "El registro ha sido actualizado"
    EXITOD = "El registro ha sido eliminado"
    ERRORDB = "Se ha producido un error accesando la base de datos"
    ERRORUD = "No existe este usuario"
    ERRORSD = "No hay datos json"
    NUMERICO = "El id debe ser numerico"
     
        
        
