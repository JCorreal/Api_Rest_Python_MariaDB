from DAL.Conexion import Conexion
from BO.Usuario import Usuario
from DAL.IAccesoDatos import IAccesoDatos



class AccesoDatos(IAccesoDatos):
    
    @classmethod 
    def obtenerListadoUsuarios(self):
        try:
            con = Conexion().obtenerConexion()
            usuarios = []            
            cur = con.cursor()
            cur.callproc("spr_Listados", [0])
        
            for result in cur.stored_results():
                usuarios = result.fetchall()   
                return usuarios
        except Exception as error:
             print("Error:", error)
        finally:
                cur.close()   
                con.close()   


    def obtenerUsuario(self, id):        
        usuario = Usuario()
        registro = []
        try:
            con = Conexion().obtenerConexion()    
            cur = con.cursor()
            cur.callproc("spr_Listados", [id])            
            registro = [result.fetchone() for result in cur.stored_results()]
            if (registro != [None]):
                usuario.usuario_id = registro[0][0]
                usuario.nombres = registro[0][1]
                usuario.apellidos = registro[0][2]
                return usuario
            else:
                return registro
        except Exception as error:
             print("Error:", error)
        finally:
                cur.close()   
                con.close()
        
  
    def guardarUsuario(self, usuario):
        
        try:
            con = Conexion().obtenerConexion()
            with con.cursor() as cursor:            
                args = (usuario.usuario_id, usuario.nombres, usuario.apellidos, 0) 
                respuesta = cursor.callproc('spr_IUUsuarios', args)                
                return respuesta[3]
        except Exception as error:
             print("Error:", error)
        finally:
                cursor.close()
                con.close()
    
    
    def eliminarUsuario(self, id):
        try:
            con = Conexion().obtenerConexion()
            with con.cursor() as cursor:            
                args = (id, 0) 
                respuesta = cursor.callproc('spr_DUsuario', args)                
                return respuesta[1]
        except Exception as error:
             print("Error:", error)
        finally:
                cursor.close()
                con.close()
    