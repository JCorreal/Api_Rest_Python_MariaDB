from DAL.Conexion import Conexion
from BO.Usuario import Usuario
from DAL.IAccesoDatos import IAccesoDatos

class AccesoDatos(IAccesoDatos):
    
    @classmethod 
    def obtenerListadoUsuarios(self):        
        conexion = Conexion().obtenerConexion()
        usuarios = []            
        obj = conexion.cursor()
        obj.callproc("spr_Listados", [0])

        for result in obj.stored_results():
            usuarios = result.fetchall()            
            conexion.close()
            return usuarios
    
    def obtenerUsuario(self, id):
        conexion = Conexion().obtenerConexion()    
        obj = conexion.cursor()
        obj.callproc("spr_Listados", [id])

        for result in obj.stored_results():
            usuario = result.fetchone()            
            conexion.close()
            return usuario
  
    def guardarUsuario(self, usuario):    
        conexion = Conexion().obtenerConexion()
        with conexion.cursor() as cursor:            
            args = (usuario.usuario_id, usuario.nombres, usuario.apellidos, 0) 
            respuesta = cursor.callproc('spr_IUUsuarios', args)
            conexion.close()
            return respuesta[3]
    
    
    def eliminarUsuario(self, id):
        conexion = Conexion().obtenerConexion()
        with conexion.cursor() as cursor:            
            args = (id, 0) 
            respuesta = cursor.callproc('spr_DUsuario', args)
            conexion.close()
            return respuesta[1]