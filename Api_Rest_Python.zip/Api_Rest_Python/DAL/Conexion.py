import mysql.connector as database

class Conexion:

    @staticmethod
    def obtenerConexion():
        connection = database.connect(host='localhost',
                                       user='root',
                                       password='',
                                       db='ApiRest_DB')
        return connection