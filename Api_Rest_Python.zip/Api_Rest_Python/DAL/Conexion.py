# Clase que nos devuelve la conexion con el proveedor que se desee (MariaDB)

import mysql.connector as database

class Conexion:

    @staticmethod
    def obtenerConexion():
        connection = database.connect(host='localhost',
                                       user='root',
                                       password='',
                                       db='ApiRest_DB')
        return connection
