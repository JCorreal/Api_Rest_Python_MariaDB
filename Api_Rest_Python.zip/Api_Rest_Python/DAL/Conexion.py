import mysql.connector

class Conexion:

    @staticmethod
    def obtenerConexion():
        return mysql.connector.connect(host='localhost',
                                       user='root',
                                       password='',
                                       db='ApiRest_DB')
