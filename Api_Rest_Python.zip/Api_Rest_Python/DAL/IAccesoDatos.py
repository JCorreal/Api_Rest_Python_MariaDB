# Interface que expone todo lo que el DAL (Capa Acceso Datos) implementa

from abc import ABC, abstractmethod

class IAccesoDatos(ABC):
    @abstractmethod
    def obtenerListadoUsuarios(self):
        pass
    
    @abstractmethod
    def obtenerUsuario(self, id):
        pass
    
    @abstractmethod
    def guardarUsuario(self, usuario):
        pass
    
    @abstractmethod
    def eliminarUsuario(self, id):
        pass
